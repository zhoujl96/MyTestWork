<?php

namespace App\Http\Controllers\Ques;

use Illuminate\Http\Request;
use App\Model\TestUser;
use App\Http\Controllers\Controller;
use App\Model\Ques\Ques;

class QuesController extends Controller
{
   
    /**
     * 题目列表查询接口
     * 古文源2018-11-5
     * @return \Illuminate\Http\Response
     */
    public function queryItems()
    {
        $rules = [
            // 'type'       => 'string',//题目类型id列表，多个以逗号分隔
            // 'sourceId'   => 'string',// 题目来源编码列表，多个以逗号分隔
            // 'subjectId'  => 'int',//学科id 
            // 'bookId'     => 'int',//教材版本册别id,
            // 'categs'     => 'string',//教材章节id,多于逗号分隔      
            // 'knows'      => 'string',//关联知识id列表,多于逗号分隔
            // 'difficult'  => 'string',//难易程度编码列表，多个以逗号分隔
            // 'paperId'    => 'int',//试卷ID
            // 'saveUserId' => 'int',//收藏用户id
            // 'uploadUserId' => 'int',//组卷用户id
            // 'quesStem'   => 'string'//根据题干内容。模糊查询
            //20200715  yanxy   新增接口参数
            // 'orderBy'    =>  'string'    //排序依据  默认    modify_time 修改时间  可选 create_time--上传时间 use_num--组卷次数
            // 'orderType' =>  'string'    //排序  默认    desc--倒序    可选 asc--正序
            // 'specialType' =>'string'    //特殊筛选条件   默认 '' 可选 knowledge--筛选知识点为空题目  explanation--筛选解答为空题目
            //  20200716  yanxy   
            // 'active' => ''  //  可选参数 题目是否可用 1查询所有可用题目（排除被禁用的题目） 2查询所有被禁用的题目    不传--查询所有题目
        ];

        if($error = $this->validateInput($rules)){
            return $error;
        }

        //小程序传输数据转换
        if(isset($this->validated["login_source"]) && $this->validated["login_source"] == "wechat"){
            $this->validated["pageArr"] = json_decode($this->validated["pageArr"],true);
        }
        $res = Ques::queryItems($this->validated);
        return $res;
    }    

    
   /**
     * [explainList 讲解列表查询接口]
     * @author [fuyy] <[email address]>
     * @param [int] $user_id [用户id]
     * @return [type] [description]
     */
    public function quesUserExpls()
    {   
        $rules = [
            'user' =>'required | int',
            'page' => 'int'
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::quesUserExpls($this->validated);
        return $data;
    }

    /**
     * 题目收藏与取消接口
     * 2018-11-14 古文源
     */
    public function saveItem() {

        $rules = [
            'quesId' =>'int',
            'save'   =>'required | int',
            'type'   =>'int',
            'userId' =>'required'  
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::saveItem($this->validated);
        return $data;
    }
    
    /**
     * 题目 掌握情况更改接口    修改
     * 2019-11-11
     */
    public function changeGra() {

        $rules = [
            'quesId' =>'required | int',
            // 'grasp'   =>'required | int',
            'userId' =>'required'  
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::changeGra($this->validated);
        return $data;
    }


    /**
     * [queryQuesResolve 题目解析查询]
     * @return [type] [description]
     */
    public function queryQuesResolve()
    {
        $rules = [ 
            'id' => 'required|int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::queryQuesResolve($this->validated);
        return $data;
    }

    /**
     * [queryQuesDetails 查询题目详情]
     * @return [type] [description]
     */
    public function queryQuesDetails()
    {
        $rules = [ 
            'id' => 'required|int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::queryQuesDetails($this->validated);
        return $data;
    }

    /**
     * [queryQuesExpls 题目视频讲解]
     * @return [type] [description]
     */
    public function queryQuesExpls()
    {
        $rules = [ 
            'quesId' => 'required|int',
            'range'  => 'int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::queryQuesExpls($this->validated);
        return $data;
    }


    public function useQuesExpl()
    {
        $rules = [ 
            'quesId' => 'required|int',
            'expId' => 'required|int',
            'user'   => 'int '
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::useQuesExpl($this->validated);
        return $data;
    }

    /**
     * 录制视频上传
     * @return [type] [description]
     */
    public function expl_upload()
    {   
        if($this->request->hasFile('file')){
            $file = $this->request->file('file');
            if(!$file->isValid()){
                return 500;
            }
            $extension = $file->getClientOriginalExtension();
            $filename = $file->getClientOriginalName();
            // $newFileName = md5($filename.time().mt_rand(1,10000)).'.'.$extension;
            $newFileName = 'dk.mp4';
            // $file->move(resource_path().'/assets/video', $newFileName);
            $file->move(public_path(), $newFileName);
        }
        return $newFileName;
    }
    /**
     * 录制信息上传
     * @return [type] [description]
     */
    public function uploadQuesExpl()
    {
        $rules = [ 
            'quesId' => 'int | required',
            'userId' => 'int | required',
            'explFileUrl'   => 'string | required'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::uploadQuesExpl($this->validated);
        return $data;
    }

    public function quesExplRecord()
    {
        $rules = [
            'userId'   => 'required|int',
            'type'      => 'required|int',
            'file'      => 'nullable | string',
            'pid'       => 'nullable | int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::quesExplRecord($this->validated);
        return $data;
    }


    // ...........................new code

    /**
     * 根据条件获取错题数目
     * @return [type] [description]
     */
    public function getWrongQuesNum()
    {
        $rules = [
            'userId'   => 'required|int',
            'subject'  => 'required|int',
            'around'   => 'string',
            'start'    => 'string',
            'end'      => 'string'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getWrongQuesNum($this->validated);
        return $data;
    }

    /**
     * 根据条件导出错题
     * @return [type] [description]
     */
    public function exportWrongQues()
    {
        $rules = [
            'userId'   => 'required|int',
            'subject'  => 'required|int',
            'around'   => 'string',
            'start'    => 'string',
            'end'      => 'string',
            'mode'     => 'int',   //模式 1为试卷模式 2为模板模式
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::exportWrongQues($this->validated);
        return $data;
    }

    /**
     * 批量导出错题
     * @return [type] [description]
     */
    public function uploadWordQues()
    {
        $rules = [];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::uploadWordQuesTest($this->validated);
        // $data = Ques::uploadWordQues($this->validated);
        return $data;
    }

    /**
     * 批量导出公式提取 zjl 2020/11/16
     * @return [type] [description]
     */
    public function uploadWordFormula()
    {
        $rules = [];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::uploadWordFormula($this->validated);
        return $data;
    }

    /**
     * 批量导出公式查询 zjl 2020/11/23
     * @return [type] [description]
     */
    public function getFormula()
    {
        $rules = [];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getFormula($this->validated);
        return $data;
    }

    /**
     * 更新公式数据表数据接口 zjl 2020/12/11
     * @return [type] [description]
     */
    public function updateFormula()
    {
        $rules = [];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::updateFormula($this->validated);
        return $data;
    }

    /**
     * 批量导入svg数据回传接口 zjl 2020/1/20
     * @return [type] [description]
     */
    public function uploadWordSvg()
    {
        $rules = [];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::uploadWordSvg($this->validated);
        return $data;
    }


    // ......................................

    // ........new code 202003

    /**
     * 获取教师试卷报告单道错题详情 2020-03-12 zjl
     * @return [type] [description]
     */
    public function getTeacherQuesDetail()
    {
        $rules = [
            'quesId'   => 'required',
            'classcode_id'   => 'required'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getTeacherQuesDetail($this->validated);
        return $data;
    }

    /**
     * 获取错题题目数据 2020-03-23 zjl
     * @return [type] [description]
     */
    public function quesWrongData()
    {
        $rules = [
            // 'pageArr' => 'required',
            'userId' => 'required',
            'subjectId' => 'required',
            'quesTypeId' => 'required',
            'dateType' => 'required',
            'startDate' => 'string',
            'endDate' => 'string'
        ];
        //小程序传输数据转换
        if(isset($this->validated["login_source"])&&$this->validated["login_source"] == "wechat"){
            $this->validated["pageArr"] = json_decode($this->validated["pageArr"],true);
        }
        if($error = $this->validateInput($rules)){
            return $error;
        }
        // $this->validated["pageArr"] = json_decode($this->validated["pageArr"],true);
        $data = Ques::quesWrongData($this->validated);
        return $data;
    }

    /**
     * 获取错题知识点数据 2020-03-23 zjl
     * @return [type] [description]
     */
    public function knowWrongData()
    {
        $rules = [
            // 'pageArr' => 'required',
            'userId' => 'required',
            'subjectId' => 'required',
            'quesTypeId' => 'required',
            'dateType' => 'required',
            'startDate' => 'string',
            'endDate' => 'string'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        // $this->validated["pageArr"] = json_decode($this->validated["pageArr"],true);
        $data = Ques::knowWrongData($this->validated);
        return $data;
    }

    /**
     * 根据单个错题知识点获取对应错题数据 2020-03-24 zjl
     * @return [type] [description]
     */
    public function getKnowQuesList()
    {
        $rules = [
            // 'pageArr' => 'required',
            'userId' => 'required',
            'knowId' => 'required',
            'quesTypeId' => 'required',
            'dateType' => 'required',
            'startDate' => 'string',
            'endDate' => 'string'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $this->validated["pageArr"] = json_decode($this->validated["pageArr"],true);
        $data = Ques::getKnowQuesList($this->validated);
        return $data;
    }

    /**
     * 根据用户id获取错题科目分类 2020-03-30 zjl
     * @return [type] [description]
     */
    public function subjectWrongList()
    {
        $rules = [
            'userId' => 'required'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::subjectWrongList($this->validated);
        return $data;
    }

    // ............

    // ........new code 202004

    /**
     * 获取指定批次的要完善的题目列表 2020/4/20 zjl
     * @return [type] [description]
     */
    public function getQuesSupplyList()
    {
        $rules = [
            'uploadcode' => 'required'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getQuesSupplyList($this->validated);
        return $data;
    }

    /**
     * 获取要完善的试题的详细信息 2020/4/21 zjl
     * @return [type] [description]
     */
    public function supplyQuesDetail()
    {
        $rules = [
            'id' => 'required|int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::supplyQuesDetail($this->validated);
        return $data;
    }

    /**
     * 保存要完善的题目 2020/4/21 zjl
     * @return [type] [description]
     */
    public function updateSupplySubject()
    {
        $rules = [

        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $res = Ques::updateSupplySubject($this->validated);
        return $res;
    }

    // ................

    // ........new code 202006

    /**
     * 上传题目的音频接口
     * @return [type] [description]
     */
    public function saveAudio()
    {
        $rules = [];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::saveAudio($this->validated);
        return $data;
    }

    // ................

    /**     20200713
     * @Author: yanxy
     * @Date: 2020-07-13 09:38:16 
     * @Desc:  获取用户错题重练试题列表接口
     */
    public function getWrongRedoData()
    {
        $rules = [
            'userId' => 'required',
            'subjectId' => 'required',
            'quesTypeId' => 'required',
            'dateType' => 'required',
            'startDate' => 'string',
            'endDate' => 'string'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getWrongRedoData($this->validated);
        return $data;
    }

    /**     20200714
     * @Author: yanxy 
     * @Date: 2020-07-14 13:57:47 
     * @Desc:  获取用户对应科目下的错题题型列表
     */
    public function quesWrongTypeData()
    {
        $rules = [
            'userId' => 'required',
            'subjectId' => 'required',
        ];

        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::quesWrongTypeData($this->validated);
        return $data;
    }

    /**     20200716
     * @Author: yanxy 
     * @Date: 2020-07-16 10:07:22 
     * @Desc:  修改试题状态接口
     */
    public function banQues()
    {
        $rules = [
            'userId' => 'required|int',
            'quesId' => 'required|int',
            'status' => 'int',
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::banQues($this->validated);
        return $data;
    }

    /**
     * 上传批量导入列表界面试题接口
     */
    public function uploadQues()
    {
        $rules = [
            'quesId' => 'required|int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::uploadQues($this->validated);
        return $data;
    }

    /** 
     * 存储错题重练记录接口
     *  20200902    yanxy
     */
    public function saveWrongRedoData()
    {
        $rules = [
            'user_id'=>'required|int'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::saveWrongRedoData($this->validated);
        return $data;
    }

    /** 
     * 获取用户错题重练记录列表
     *  20200902    yanxy
     */
    public function getWrongRedoList()
    {
        $rules = [
            'user_id'=>'required|int',
            'subject_id'=>'int',
            'login_source'=>'string'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        //小程序传输数据转换
        if($this->validated["login_source"] == "wechat"){
            $this->validated["pageArr"] = json_decode($this->validated["pageArr"],true);
        }
        $data = Ques::getWrongRedoList($this->validated);
        return $data;
    }

    /** 
     * 获取用户错题重练记录数据
     *  20200902    yanxy
     */
    public function getWrongRedoReport()
    {
        $rules = [
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getWrongRedoReport($this->validated);
        return $data;
    }

    /**
     * 上传指定批次所有题目并移除上传成功的题目接口
     */
    public function uploadAllQues()
    {
        $rules = [
            'uploadcode' => 'required'
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::uploadAllQues($this->validated);
        return $data;
    }


    /**
     * 识别子题目信息接口 20200828 zhoujl
     */
    public function getChildQuesInfo()
    {
        $rules = [
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getChildQuesInfo($this->validated);
        return $data;
    }

    /**
     * 查询子题目信息接口 20200831 zhoujl
     */
    public function queryChildQuesInfo()
    {
        $rules = [
        ];
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::queryChildQuesInfo($this->validated);
        return $data;
    }

    /**
     * 导出保存的题目id串对应的题目数据 20201127 zhoujl
     */
    public function getSaveQuesData()
    {
        $rules = [
            'quesList' => 'required'
        ];

        if($error = $this->validateInput($rules)){
            return $error;
        }
        $this->validated["quesList"] = json_decode($this->validated["quesList"],true);
        $data = Ques::getSaveQuesData($this->validated);
        return $data;
    }

    

    /**
     * 查询付费后题目解析 20210120 yanxy
     */
    public function getQuesAllExplanation()
    {
        $rules = [
            'quesId' => 'required'
        ];

        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Ques::getQuesAllExplanation($this->validated);
        return $data;
    }
}


<?php

namespace App\Http\Controllers\Supplies;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Supplies\Supplies;

class SuppliesController extends Controller
{
    // 新建物资条目
    public function createSupplies()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::createSupplies($this->validated);
        return $data;
    }

    // 修改物资条目
    public function editSupplies()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::editSupplies($this->validated);
        return $data;
    }

    // 删除物资条目
    public function removeSupplies()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::removeSupplies($this->validated);
        return $data;
    }

    // 根据id获取物资条目
    public function getSuppliesOne()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::getSuppliesOne($this->validated);
        return $data;
    }

    // 获取储备类型接口
    public function getStoreTypeData()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::getStoreTypeData($this->validated);
        return $data;
    }

    // 获取物资类别接口
    public function getCategoryData()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::getCategoryData($this->validated);
        return $data;
    }

    // 自定义操作添加新类别
    public function appendCategory()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::appendCategory($this->validated);
        return $data;
    }
    // 自定义操作修改类别
    public function editCategory()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::editCategory($this->validated);
        return $data;
    }
    // 自定义操作删除类别
    public function removeCategory()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::removeCategory($this->validated);
        return $data;
    }

    // 获取物资数据接口
    public function getSuppliesData()
    {   
        $rules = [
        ];
        
        if($error = $this->validateInput($rules)){
            return $error;
        }
        $data = Supplies::getSuppliesData($this->validated);
        return $data;
    }
}
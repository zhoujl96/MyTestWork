<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

use Illuminate\Http\Request;
use App\Models\BaseModel;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public $request = '';
    public $validated;

    // 请求参数认证
    public function __construct()
    {
        $this->request = app('request');   // 所有的请求参数
        $this->validated = $this->request->all();  // 用户传上来的请求参数
        
        
    }

    // 验证规则
    public function validateInput($rules)
    {
        $messages = [
            'required'  => 'validated required',
            'string'    => 'validated must be string',
            'int'       => 'validated must be int'
        ];
        $attributes = [
        ];

        $validator = \Validator::make($this->validated, $rules,$messages, $attributes);
        if ($validator->fails()) {
            return BaseModel::formatError(BaseModel::BAD_REQUEST, $validator->messages()->first());
            // return $validator->errors()->all();         //显示所有错误组成的数组
            // return $validator->messages()->first();     //显示第一条错误
        }
        return false;
    }
}

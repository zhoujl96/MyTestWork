<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BaseModel extends Model
{
    const UNKNOWN_ERROR  = 0;

    const NOT_FOUND     = 404;
    const BAD_REQUEST   = 400;
    const ORDER_EXISTS  = 502;

    public static $tableArr = [
        'category' => 'T_RELIEF_CATEGORY',
        'storeType' => 'T_RELIEF_STORE_TYPE',
        'supplies' => 'T_RELIEF_SUPPLIES'
    ];

    /**
     * [formatBody 正确数据返回格式]
     * @param  [type] $response [description]
     * @return [type]           [description]
     */
    public static function formatBody($response)
    {
        $data['resCode']    = '000';
        $data['result']     = true;
        $data['msg']        = 'success';
        $data['data']       = $response;
        return $data;
    }

    /**
     * [formatError 错误数据返回格式]
     * @param  [type] $code    [description]
     * @param  [type] $message [description]
     * @return [type]          [description]
     */
    public static function formatError($code, $message = null, $data = '')
    {
        switch ($code) {
            case self::UNKNOWN_ERROR:
                $message = 'An unknown error';
                break;

            case self::NOT_FOUND:
                $message = '404 Not Found';
                break;

            case self::ORDER_EXISTS:
                $message = '502 Order Exists';
                break;
        }

        $body['result'] = false;
        $body['resCode'] = $code;
        $body['msg'] = $message;
        $body['data'] = $data;
        return $body;
    }
}
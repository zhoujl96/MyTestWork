<?php

namespace App\Models\Supplies;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use App\Models\BaseModel;
use Illuminate\Support\Facades\DB;

class Supplies extends BaseModel
{
    // 新建物资条目接口
    public static function createSupplies($attribute)
    {
        extract($attribute);

        $time = time();
        $attribute['create_time'] = date('Y-m-d H:i:s', $time);

        DB::table(self::$tableArr['supplies'])->insertGetId($attribute);

        return self::formatBody($attribute);
    }
    // 修改物资条目接口
    public static function editSupplies($attribute)
    {
        extract($attribute);

        $suppliesOne = [
            'size' => $size,
            'active' => $active,
            'storeType_id' => $storeType_id,
            'storeType' => $storeType,
            'order' => $order,
            'weight' => $weight,
            'volume' => $volume,
            'usage' => $usage

        ];

        DB::table(self::$tableArr['supplies'])
            ->where(['id'=> $id])->update($suppliesOne);

        return self::formatBody($attribute);
    }

    // 删除物资条目接口
    public static function removeSupplies($attribute)
    {
        extract($attribute);

        DB::table(self::$tableArr['supplies'])
            ->whereIn('id', $ids)->update(['exit'=>0]);

        return self::formatBody($attribute);
    }


    // 获取储备类型接口
    public static function getStoreTypeData($attribute)
    {
        extract($attribute);

        $storeTypeData = DB::table(self::$tableArr['storeType'])
            ->select('id', 'name')
            ->where(['active'=>1])
            ->orderBy('id')
            ->get();

        return self::formatBody($storeTypeData);
    }

    // 获取物资类别接口
    public static function getCategoryData($attribute)
    {
        extract($attribute);

        $categoryStruct = self::getCategory();

        return self::formatBody($categoryStruct);
    }

    // 自定义操作添加新类别
    public static function appendCategory($attribute)
    {
        extract($attribute);

        // 添加新类别
        $newCategory = [
            'name' => $name,
            'up_id' => $up_id,
            'active' => 1
        ];
        DB::table(self::$tableArr['category'])->insertGetId($newCategory);

        $categoryStruct = self::getCategory();

        return self::formatBody($categoryStruct);
    }
    // 自定义操作修改类别
    public static function editCategory($attribute)
    {
        extract($attribute);

        // 修改类别
        $category = [
            'name' => $name
        ];
        DB::table(self::$tableArr['category'])
            ->where(['id'=>$id])
            ->update($category);

        $categoryStruct = self::getCategory();

        return self::formatBody($categoryStruct);
    }
    // 自定义操作删除类别
    public static function removeCategory($attribute)
    {
        extract($attribute);

        // 删除类别
        $category = [
            'active' => 0
        ];

        $ids = [$id];
        if(isset($children)) {
            $ids = array_merge($ids, self::getChild($children));
        }
        

        DB::table(self::$tableArr['category'])
            ->whereIn('id', $ids)
            ->update($category);

        DB::table(self::$tableArr['supplies'])
            ->whereIn('category_id', $ids)
            ->update(['exit'=>0]);

        $categoryStruct = self::getCategory();

        return self::formatBody($categoryStruct);
    }

    // 获取物资类别共用函数
    public static function getCategory()
    {
        // 获取物质类别结构
        $categoryData = DB::table(self::$tableArr['category'])
            ->select('id', 'up_id as ui', 'name as label')
            ->where(['active'=>1])
            ->orderBy('id')
            ->get();

        $categoryArray = [];

        foreach($categoryData as $key => $value) {
			$value = get_object_vars($value);
			$categoryArray[$value['id']] = $value;
		}
		$categoryStruct = [];
		foreach($categoryData as $key => $value) {	
			$value = get_object_vars($value);	
			if(isset($categoryArray[$value['ui']])){
				$categoryArray[$value['ui']]['children'][] = &$categoryArray[$value['id']];
			}else if($categoryArray[$value['id']]['label']){
				$categoryStruct[] = &$categoryArray[$value['id']];				
			}	
		}
        return $categoryStruct;
    }

    // 递归获取所有子节点
    public static function getChild($children)
    {
        $ids = [];
        foreach($children as $key => $value) {
            $ids = array_merge($ids, [$value['id']]);
            if(array_key_exists('children', $value)) {
                $ids = array_merge($ids, self::getChild($value['children']));
            }
        }
        return $ids;
        
    }

    // 根据id获取物资条目
    public static function getSuppliesOne($attribute)
    {
        extract($attribute);

        $suppliesOne = DB::table(self::$tableArr['supplies'])
            ->select('id', 'name', 'category_id', 'category', 'unit', 'size', 'active', 'storeType_id', 'storeType', 'order', 'weight', 'volume', 'usage', 'exit', 'create_time')
            ->where(['exit'=>1, 'id'=>$id])
            ->orderBy('id')->first();

        return self::formatBody($suppliesOne);
    }

    // 获取物资数据接口
    public static function getSuppliesData($attribute)
    {
        extract($attribute);

        // 查询物资数据
        $suppliesData = DB::table(self::$tableArr['supplies'])
            ->select('id', 'name', 'category_id', 'category', 'unit', 'size', 'active', 'storeType_id', 'storeType', 'order', 'weight', 'volume', 'usage', 'exit', 'create_time')
            ->where(['exit'=>1])
            ->orderBy('id');

        if(isset($select_categoryId)) {
            $ids = [$select_categoryId];
            if(isset($select_children)) {
                $ids = array_merge($ids, self::getChild($select_children));
            }
            $suppliesData->whereIn('category_id', $ids);
        }

        if(isset($select_active)) {
            $suppliesData->where(['active'=>$select_active]);
        }

        if(isset($select_size)) {
            $suppliesData->where('size', 'like', '%'.$select_size.'%');
        }
        
        // 分页操作
        $attributes['db'] = $suppliesData;

        if(isset($page)) {
            $attributes['page'] = $page;
        }
        if(isset($pageSize)) {
            $attributes['pageSize'] = $pageSize;
        }
        $pageArr = self::pageLimit($attributes);
        $returnData['pageArr'] = $pageArr;

        $returnData['data'] = $suppliesData
            ->skip(($pageArr['page']-1)*$pageArr['pageSize'])
            ->take($pageArr['pageSize'])
            ->get();

        return self::formatBody($returnData);
    }

    /**
     * 分页处理
     * @return [type] [description]
     */
    public static function pageLimit($attributes) 
    {
        extract($attributes);
        // 是否传了 page
        if(empty($page)) {
            $page = 1;
        }
        // 是否传了 pageSize
        if(empty($pageSize)){
            $pageSize = 10;
        }
        // 基于当前条件计算总数量
        $count = $db->count();
                
                
        $pageSum = ceil($count / $pageSize);
        $pageArr = [
            'pageSum'   => $pageSum,
            'count'     => $count,
            'page'      => $page,
            'pageSize'  => $pageSize
        ];
        return $pageArr;
    }
}
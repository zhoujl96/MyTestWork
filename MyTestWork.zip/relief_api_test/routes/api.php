<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['namespace' => 'Supplies'], function ($app) {
    // 新建物资条目
    $app->post('relief/supplies/createSupplies', 'SuppliesController@createSupplies');
    // 修改物资条目
    $app->post('relief/supplies/editSupplies', 'SuppliesController@editSupplies');
    // 删除物资条目
    $app->post('relief/supplies/removeSupplies', 'SuppliesController@removeSupplies');
    // 根据id获取物资条目
    $app->post('relief/supplies/getSuppliesOne', 'SuppliesController@getSuppliesOne');
    // 获取储备类型
    $app->post('relief/supplies/getStoreTypeData', 'SuppliesController@getStoreTypeData');
    // 获取物资类别
    $app->post('relief/supplies/getCategoryData', 'SuppliesController@getCategoryData');
    // 自定义操作添加新类别
    $app->post('relief/supplies/appendCategory', 'SuppliesController@appendCategory');
    // 自定义操作修改类别
    $app->post('relief/supplies/editCategory', 'SuppliesController@editCategory');
    // 自定义操作删除类别
    $app->post('relief/supplies/removeCategory', 'SuppliesController@removeCategory');
    // 获取物资数据
    $app->post('relief/supplies/getSuppliesData', 'SuppliesController@getSuppliesData');
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

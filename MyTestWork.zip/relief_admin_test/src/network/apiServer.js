import Vue from 'vue'
import API from './API/appApi'

Vue.prototype.API = API;
import Vue from 'vue'
import axios from 'axios'
import GLOBAL_CONFIG from '../../config/config'

const CONFIG = GLOBAL_CONFIG['GLOBAL_CONFIG'];
const APIURL = CONFIG['API_HOST'];

export default {
	// 新建物资条目
	createSupplies(data) {
		return this.post('/relief/supplies/createSupplies', data);
	},
	// 修改物资条目
	editSupplies(data) {
		return this.post('/relief/supplies/editSupplies', data);
	},
	// 删除物资条目
	removeSupplies(data) {
		return this.post('/relief/supplies/removeSupplies', data);
	},
	// 根据id获取物资条目
	getSuppliesOne(data) {
		return this.post('/relief/supplies/getSuppliesOne', data);
	},
	// 获取储备类型
	getStoreTypeData(data) {
		return this.post('/relief/supplies/getStoreTypeData', data);
	},
	// 获取物质类别
	getCategoryData(data) {
		return this.post('/relief/supplies/getCategoryData', data);
	},

	// 自定义操作添加新类别
	appendCategory(data) {
		return this.post('/relief/supplies/appendCategory', data);
	},
	// 自定义操作修改类别
	editCategory(data) {
		return this.post('/relief/supplies/editCategory', data);
	},
	// 自定义操作删除类别
	removeCategory(data) {
		return this.post('/relief/supplies/removeCategory', data);
	},

	// 获取物资数据
	getSuppliesData(data) {
		return this.post('/relief/supplies/getSuppliesData', data);
	},

	//基础方法
    post(interfacePath, data) {
        return axios.post(APIURL + interfacePath,data);
    },
}

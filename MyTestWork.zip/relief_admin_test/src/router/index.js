import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      redirect: '/index'
    },
    {
      path: '/',
      component: resolve => require(['../components/common/Home.vue'], resolve),
      children:[
        {
          path: '/index',
          component: resolve => require(['../components/page/SuppliesManage.vue'], resolve),
        }
      ]
    }
  ]
})

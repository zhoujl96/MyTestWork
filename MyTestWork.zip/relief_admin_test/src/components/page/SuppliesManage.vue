<template>
    <div class="table">
        <el-row :gutter="20">
            <el-col :span="7">
                <div>
                    <el-input v-model="select_word" placeholder="请输入搜索关键字" class="handle-input1"></el-input>
                    <el-tree
                        class="filter-tree"
                        node-key="id"
                        :highlight-current="true"
                        :data="treedata"
                        :props="defaultProps"
                        default-expand-all
                        :expand-on-click-node="false"
                        :filter-node-method="filterNode"
                        @node-click="handleNodeClick"
                        ref="treedata">
                        <span class="custom-tree-node" slot-scope="{ node, data }">
                            <span>{{ node.label }}</span>
                            <span>
                                <el-button
                                    type="text"
                                    size="mini"
                                    @click="() => append(data)">
                                    添加
                                </el-button>
                                <el-button
                                    type="text"
                                    size="mini"
                                    @click="() => edit(data)">
                                    编辑
                                </el-button>
                                <el-button
                                    type="text"
                                    size="mini"
                                    @click="() => remove(node, data)">
                                    删除
                                </el-button>
                            </span>
                        </span>
                    </el-tree>
                </div>
            </el-col>
            <el-col :span="17" class="container">
                <div>
                    <el-row :gutter="20">
                        <el-col :span="12">
                            <el-form ref="form" label-width="80px">
                                <el-form-item label="规格/型号">
                                    <el-input v-model="select_size" placeholder="请输入规格/型号" class="handle-input2"></el-input>
                                </el-form-item>
                            </el-form>
                        </el-col>
                        <el-col :span="12">
                            <el-row :gutter="20">
                                <el-form ref="form" label-width="80px">
                                    <el-form-item label="是否有效">
                                        <el-select v-model="select_active" placeholder="请选择是否有效" class="handle-input">
                                            <el-option v-for="(item, index) in activeData" :key="index" :label="item.label" :value="item.id"></el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-form>
                            </el-row>    
                            <el-row :gutter="20" class="buttons">
                                <el-button type="primary" @click="search(1)">查询</el-button>
                                <el-button @click="handleReset">重置</el-button>
                            </el-row>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20" class="buttons">
                        <el-button type="primary" @click="handleCreate">新增</el-button>
				        <el-button type="danger" @click="handleDelete">删除</el-button>
                    </el-row>
                    <el-row :gutter="20" class="myTable">
                        <div class="tipTextDiv">
                            <i class="el-icon-info"></i>
                            <span class="tipText">
                                已选择
                                <span class="tipTextNum">
                                    {{selectNum}}
                                </span>
                                项
                            </span>
                            <el-button
                                type="text"
                                size="mini"
                                @click="toggleSelection()">
                                清空
                            </el-button>
                        </div>
                        <el-table 
                            id="suppliesList" 
                            height="420"
                            :data="data" 
                            border class="myTable" 
                            ref="multipleTable"
                            @selection-change="handleSelectionChange">
                            <el-table-column type="selection" width="50" align="center">
                            </el-table-column>
                            <el-table-column  label="序号" width="50" align="center">
                                <template slot-scope="scope">
                                    {{scope.$index+1+startNum}} 
                                </template>
                            </el-table-column>
                            <el-table-column prop="name" label="物资品名" width="180" align="center">
                            </el-table-column>
                            <el-table-column prop="size" label="规格/型号" width="180" align="center">
                            </el-table-column>
                            <el-table-column prop="storeType" label="储备类型" width="150" align="center">
                            </el-table-column>
                            <el-table-column prop="activeName" label="是否有效" width="120" align="center">
                            </el-table-column>
                            <el-table-column prop="order" label="排序" width="120" align="center">
                            </el-table-column>				
                            <el-table-column label="操作">
                                <template slot-scope="scope">
                                    <el-button type="text" icon="el-icon-lx-info" @click="handleEdit(scope.row.id)">编辑</el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div class="pagination" align="right">
                            <el-pagination 
                                :page-sizes="[10, 20, 30, 40]"
                                background 
                                @size-change="handleSizeChange"
                                @current-change="handleCurrentChange" 
                                :current-page.sync="cur_page" 
                                :page-size="pageSize" 
                                layout="total, prev, pager, next, sizes, jumper" 
                                :total="dtaTotal">
                            </el-pagination>
                        </div>
                    </el-row>
                </div>
            </el-col>
        </el-row>

        <!-- 新建物资操作 -->
        <el-dialog
            title="新建物资"
            class="createContent" 
            :visible.sync="createVisible" 
            width="750px">
            <el-form
                ref="newSuppliesData"
                :inline="true" 
                :model="newSuppliesData" 
                class="demo-form-inline"
                :rules="rules"
                label-width="100px">
                <el-form-item label="物资品名" prop="name">
                    <el-input class="form-input" v-model="newSuppliesData.name" placeholder="请输入新物资品名"></el-input>
                </el-form-item>
                <el-form-item label="物资类别" prop="category_id">
                    <el-select class="form-input" v-model="newSuppliesData.category_id" placeholder="请输入物资类别">
                        <el-option v-for="(item, index) in categoryData" :key="index" :class="item.childnum" :label="item.label" :value="item.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="计量单位" prop="unit">
                    <el-input class="form-input" v-model="newSuppliesData.unit" placeholder="请输入计量单位"></el-input>
                </el-form-item>
                <el-form-item label="规格/型号" prop="size">
                    <el-input class="form-input" v-model="newSuppliesData.size" placeholder="请输入规格/型号"></el-input>
                </el-form-item>
                <el-form-item label="是否有效" prop="active">
                    <el-radio v-model="newSuppliesData.active" label="1">是</el-radio>
                    <el-radio v-model="newSuppliesData.active" label="0">否</el-radio>
                </el-form-item>
                <el-form-item label="储备类型" prop="storeType_id">
                    <el-select class="form-input" v-model="newSuppliesData.storeType_id" placeholder="请输入储备类型">
                        <el-option v-for="(item, index) in storeTypeData" :key="index" :label="item.name" :value="item.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="排序" prop="order">
                    <el-input class="form-input" type="number" v-model="newSuppliesData.order" placeholder="请输入排序"></el-input>
                </el-form-item>
                <el-form-item label="重量" prop="weight">
                    <el-input class="form-input" v-model="newSuppliesData.weight" placeholder="请输入重量"></el-input>
                </el-form-item>
                <el-form-item label="体积" prop="volume">
                    <el-input class="form-input" v-model="newSuppliesData.volume" placeholder="请输入体积"></el-input>
                </el-form-item>
                <el-form-item label="物资用途" prop="usage" class="textareaContent">
                    <el-input
                        class="form-input1"
                        type="textarea"
                        :autosize="{ minRows: 2, maxRows: 4}"
                        placeholder="请输入物资用途"
                        v-model="newSuppliesData.usage">
                    </el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="handleCreateSupplies('newSuppliesData')">保存</el-button>
                <el-button @click="handleReturn">返 回</el-button>
            </span>
        </el-dialog>
        <!-- 修改物资操作 -->
        <el-dialog 
            title="修改物资"
            class="editContent" 
            :visible.sync="editVisible" 
            width="750px">
            <el-form
                ref="editSuppliesData"
                :inline="true" 
                :model="editSuppliesData" 
                class="demo-form-inline"
                :rules="rules"
                label-width="100px">
                <el-form-item label="物资品名" prop="name">
                    <el-input class="form-input" v-model="editSuppliesData.name" placeholder="请输入新物资品名" disabled></el-input>
                </el-form-item>
                <el-form-item label="物资类别" prop="category_id">
                    <el-select class="form-input" v-model="editSuppliesData.category_id" placeholder="请输入物资类别" disabled>
                        <el-option v-for="(item, index) in categoryData" :key="index" :class="item.childnum" :label="item.label" :value="item.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="计量单位" prop="unit">
                    <el-input class="form-input" v-model="editSuppliesData.unit" placeholder="请输入计量单位" disabled></el-input>
                </el-form-item>
                <el-form-item label="规格/型号" prop="size">
                    <el-input class="form-input" v-model="editSuppliesData.size" placeholder="请输入规格/型号"></el-input>
                </el-form-item>
                <el-form-item label="是否有效" prop="active">
                    <el-radio v-model="editSuppliesData.active" label="1">是</el-radio>
                    <el-radio v-model="editSuppliesData.active" label="0">否</el-radio>
                </el-form-item>
                <el-form-item label="储备类型" prop="storeType_id">
                    <el-select class="form-input" v-model="editSuppliesData.storeType_id" placeholder="请输入储备类型">
                        <el-option v-for="(item, index) in storeTypeData" :key="index" :label="item.name" :value="item.id"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="排序" prop="order">
                    <el-input class="form-input" type="number" v-model="editSuppliesData.order" placeholder="请输入排序"></el-input>
                </el-form-item>
                <el-form-item label="重量" prop="weight">
                    <el-input class="form-input" v-model="editSuppliesData.weight" placeholder="请输入重量"></el-input>
                </el-form-item>
                <el-form-item label="体积" prop="volume">
                    <el-input class="form-input" v-model="editSuppliesData.volume" placeholder="请输入体积"></el-input>
                </el-form-item>
                <el-form-item label="物资用途" prop="usage" class="textareaContent">
                    <el-input
                        class="form-input1"
                        type="textarea"
                        :autosize="{ minRows: 2, maxRows: 4}"
                        placeholder="请输入物资用途"
                        v-model="editSuppliesData.usage">
                    </el-input>
                </el-form-item>
                <el-form-item label="创建时间" prop="createTimeYMD">
                    <el-input class="form-input" v-model="editSuppliesData.createTimeYMD" disabled></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="handleEditSupplies('editSuppliesData')">保存</el-button>
                <el-button @click="handleReturn">返 回</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    let id = 1000;
    export default {
        name: 'SuppliesManage',
        data() {
            const treedata = [];

            return {
                newSuppliesData: {},
                editSuppliesData: {},

                rules:{
                    name: [
                        { required: true, message: '请输入物资品名', trigger: 'blur' },
                        { max: 10, message: '物资品名字数请控制在10个以内', trigger: 'blur' }
                    ],
                    size: [
                        { required: true, message: '请输入规格/型号', trigger: 'blur' }
                    ],
                    active: [
                        { required: true, message: '请选择是否有效', trigger: 'blur' }
                    ],
                    storeType_id: [
                        { required: true, message: '请输入储备类型', trigger: 'blur' }
                    ],
                    order: [
                        { required: true, message: '请输入排序', trigger: 'blur' }
                    ]
                },

                createVisible: false,
                editVisible: false,

                treedata: JSON.parse(JSON.stringify(treedata)),
                select_word: '',

                select_categoryId: 0,
                select_children: [],

                select_size: '',
                select_active: '',
                tableData: [],
                cur_page: 1,
                dtaTotal:100,
				pageSize:10,
                startNum:0,

                activeData: [{
                    id: '1',
                    label: '是'
                },{
                    id: '0',
                    label: '否'
                }],

                multipleSelection: [],

                filterText: '',
                
                defaultProps: {
                    children: 'children',
                    label: 'label'
                },

                selectNum: 0,

                treeSelection: [],

                storeTypeData: [],

                categoryData: []
            }
        },
        created() {
            this.getStoreTypeData();
            this.getCategoryData();
            this.getSuppliesData();
        },
        computed: {
            data() {
                return this.tableData.filter((d) => {
                    return d;
                })
            },
        },
        watch: {
            select_word(val) {
                this.$refs.treedata.filter(val);
            }
        },
        methods: {
            // 重置操作
            handleReset() {
                this.select_size = '';
                this.select_active = '';
                this.search(1);
            },

            // 获取储备类型
            getStoreTypeData(params) {
                this.API.getStoreTypeData(params).then((response)=>{
                    if(response.result) {
                        this.storeTypeData = response.data;
                    }
                })
            },

            // 获取物质类别
            getCategoryData(params) {
                this.API.getCategoryData(params).then((response)=>{
                    if(response.result) {
                        this.treedata = response.data;
                    }

                })
            },

            childfor(res){
                res.obj.forEach((v,k) => {
                    v['childnum'] = ['childnum'+res.num];
                    this[res.str].push(v)
                    if(v.children && v.children.length){
                        var num = res.num + 1;
                        this.childfor({obj:v.children,str:res.str,num:num});
                    }
                })
            },

            // 删除操作对应函数
            handleDelete(val) {
                if(this.multipleSelection.length == 0) {
                     this.$alert('请先选中要删除的数据', '提示', {
                        confirmButtonText: '确定'
                    });
                } else {
                    this.$confirm('将删除'+ this.selectNum +'条数据，是否继续?', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(() => {
                        let ids = [];
                        this.multipleSelection.forEach((value, index)=>{
                            ids.push(value['id']);
                        })
                        this.API.removeSupplies({'ids': ids}).then((response)=>{
                            if(response.result) {
                                this.$message({
                                    type: 'success',
                                    message: '删除成功!'
                                });
                                this.search();
                            }
                        }) 
                        
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });          
                    });
                }

            },

            // 新建操作对应函数
            handleCreate(val) {
                this.createVisible = true;
                this.categoryData = [];
                this.childfor({obj: this.treedata, str: 'categoryData', num:0});
            },
            handleCreateSupplies(params) {
                this.$refs[params].validate((valid) => {
                    if (valid) {
                        this.categoryData.forEach((value)=>{
                            if(value['id']==this.newSuppliesData.category_id) {
                                this.newSuppliesData['category'] = value['label'];
                            }
                        })
                        this.storeTypeData.forEach((value)=>{
                            if(value['id']==this.newSuppliesData.storeType_id) {
                                this.newSuppliesData['storeType'] = value['name'];
                            }
                        })

                        this.API.createSupplies(this.newSuppliesData).then((response)=>{
                            if(response.result) {
                                this.newSuppliesData = {};
                                this.createVisible = false;
                                this.$message({
                                    type: 'success',
                                    message: '新建物资条目成功'
                                });
                                this.search(1);
                            }
                        })

                    } else {
                        return false;
                    }
                });
            },

            // 编辑操作对应函数
            handleEdit(id) {
                this.editVisible = true;
                this.categoryData = [];
                this.childfor({obj: this.treedata, str: 'categoryData', num:0});
                this.API.getSuppliesOne({'id': id}).then((response)=>{
                    if(response.result) {
                        this.editSuppliesData = response.data;
                        this.editSuppliesData['active'] = this.editSuppliesData['active'].toString();
                        this.editSuppliesData['createTimeYMD'] = this.editSuppliesData['create_time'].slice(0,10);
                    }
                })
            },
            handleEditSupplies(params) {
                this.$refs[params].validate((valid) => {
                    if (valid) {
                        console.log(this.editSuppliesData);
                        
                        this.storeTypeData.forEach((value)=>{
                            if(value['id']==this.editSuppliesData.storeType_id) {
                                this.editSuppliesData['storeType'] = value['name'];
                            }
                        })

                        this.API.editSupplies(this.editSuppliesData).then((response)=>{
                            if(response.result) {
                                this.editSuppliesData = {};
                                this.editVisible = false;
                                this.$message({
                                    type: 'success',
                                    message: '修改物资条目成功'
                                });
                                this.search(1);
                            }
                        })

                    } else {
                        return false;
                    }
                });
            },

            // 返回按钮
			handleReturn () {
                this.editVisible = false;
                this.createVisible = false;
            },

            handleNodeClick(data) {
                this.select_children = [];
                this.select_categoryId = data.id;
                if (data.hasOwnProperty('children')) {
                    this.select_children = data.children;
                }
                this.search(1);
            },

            // 自定义操作添加新类别
            append(data) {
                this.$prompt('请输入新类别名称', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    if(value) {
                        let params = {};
                        params.up_id = data.id;
                        params.name = value;
                        this.API.appendCategory(params).then((response)=>{
                            if(response.result) {
                                this.treedata = response.data;
                                this.$message({
                                    type: 'success',
                                    message: '添加类别名称为: ' + value
                                });
                            }
                        })
                    }else{
                        this.$message({
                            message: '物资类别名称不能为空，请重新输入！',
                            type: 'warning'
                        });
                    }

                    // const newChild = { id: id++, label: value, children: [] };
                    // if (!data.children) {
                    //     this.$set(data, 'children', []);
                    // }
                    // data.children.push(newChild);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消添加新类别'
                    });       
                });
            },
            // 自定义操作编辑新类别
            edit(data) {
                this.$prompt('请修改类别名称', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消'
                }).then(({ value }) => {
                    if(value) {
                        let params = {};
                        params.id = data.id;
                        params.name = value;
                        this.API.editCategory(params).then((response)=>{
                            if(response.result) {
                                this.treedata = response.data;
                                this.$message({
                                    type: 'success',
                                    message: '修改类别名称为: ' + value
                                });
                            }
                        })
                    }else{
                        this.$message({
                            message: '物资类别名称不能为空，修改失败！',
                            type: 'warning'
                        });
                    }
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消修改类别'
                    });       
                });
            },
            // 自定义操作删除类别
            remove(node, data) {
                if(data.ui==0) {
                    this.$alert('该物质类别不允许被删除', '提示', {
                        confirmButtonText: '确定'
                    });
                } else if (data.hasOwnProperty('children')) {
                    this.$confirm('此操作将删除该物资类别，并会一并删除其下属所有子类别，属于这些类别的物资条目也会被删除，是否继续?', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(() => {
                        let params = {};
                        params.id = data.id;
                        params.children = data.children;
                        this.API.removeCategory(params).then((response)=>{
                            if(response.result) {
                                this.treedata = response.data;
                                this.search(1);
                                this.$message({
                                    type: 'success',
                                    message: '删除成功!'
                                });
                            }
                        })                
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });          
                    });
                } else {
                    this.$confirm('此操作将删除该物资类别，属于该类别的物资条目也会被删除，是否继续?', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(() => {
                        let params = {};
                        params.id = data.id;
                        this.API.removeCategory(params).then((response)=>{
                            if(response.result) {
                                this.treedata = response.data;
                                this.search(1);
                                this.$message({
                                    type: 'success',
                                    message: '删除成功!'
                                });
                            }
                        }) 
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });          
                    });
                }

                // const parent = node.parent;
                // const children = parent.data.children || parent.data;
                // const index = children.findIndex(d => d.id === data.id);
                // children.splice(index, 1);
            },

            renderContent(h, { node, data, store }) {
                return (
                <span class="custom-tree-node">
                    <span>{node.label}</span>
                    <span>
                        <el-button size="mini" type="text" on-click={ () => this.append(data) }>添加</el-button>
                        <el-button size="mini" type="text" on-click={ () => this.edit(data) }>编辑</el-button>
                        <el-button size="mini" type="text" on-click={ () => this.remove(node, data) }>删除</el-button>
                    </span>
                </span>);
            },

            filterNode(value, treedata) {
                if (!value) return true;
                return treedata.label.indexOf(value) !== -1;
            },

            // 分页导航
            handleCurrentChange(val) {
				// 当前搜索条件，也要				
                this.cur_page = val;
				this.search(val);
                // this.getData({'page':val});
            },

            // 改变每页大小
            handleSizeChange(val) {
                this.pageSize = val;
                this.search(1);
            },

            toggleSelection(rows) {
                if (rows) {
                    rows.forEach(row => {
                        this.$refs.multipleTable.toggleRowSelection(row);
                    });
                } else {
                    this.$refs.multipleTable.clearSelection();
                }
            },

            handleSelectionChange(val) {
                this.multipleSelection = val;
                this.selectNum = this.multipleSelection.length;
            },

            // 获取物资数据
            getSuppliesData(params) {
                this.API.getSuppliesData(params).then((response)=>{
                    if(response.result) {
                        this.tableData = response.data.data;
                        this.tableData.forEach((value, index)=>{
                            if(value['active']==1) {
                                this.tableData[index]['activeName'] = '是';
                            }else {
                                this.tableData[index]['activeName'] = '否';
                            }
                        });
                        this.startNum = (response.data.pageArr.page-1)*response.data.pageArr.pageSize;
						this.dtaTotal = response.data.pageArr.count;
						this.pageSize  = response.data.pageArr.pageSize;
					}
                })
            },

            // 搜索函数
            search(data) {
                var params = {};
                // 当前页数
                params.page = data;
                params.pageSize = this.pageSize;
                this.cur_page = data;

                if(this.select_categoryId) {
                    params.select_categoryId = this.select_categoryId;
                }
                if(this.select_children.length != 0) {
                    params.select_children = this.select_children;
                }

                if(this.select_size!='') {
                    params.select_size = this.select_size;
                }
                if(this.select_active!='') {
                    params.select_active = this.select_active;
                }
                this.getSuppliesData(params);
            },
        }
    }
</script>

<style scoped>
    .custom-tree-node {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 14px;
        padding-right: 8px;
    }
    .handle-input1 {
        width: 100%;
    }
    .handle-input2 {
        width: 200px;
    }
    .buttons {
        padding-left: 10px;
    }
    
    .table {
        margin: 10px 20px;
    }
    .myTable {
        padding: 5px 10px;
    }
    .tipTextDiv {
        margin: 5px 0;
        padding: 5px 10px;
        background: rgba(160,207,255, 0.2);
    }
    .tipText {
        font: 14px Base;
        padding-right: 20px;
    }
    .tipTextNum {
        color: #409EFF;
    }
    .el-form-item {
        width: 320px;
    }
    .childnum0{
		padding-left:10px;
	}
    .childnum1{
		padding-left:20px;
	}
	.childnum2{
		padding-left:30px;
	}
	.childnum3{
		padding-left:40px;
	}
	.childnum4{
		padding-left:50px;
	}
	.childnum5{
		padding-left:60px;
	}
	.childnum6{
		padding-left:70px;
	}
    .form-input{
        width: 220px;
    }
    .form-input1{
        width: 500px;
    }

    .textareaContent {
        width: 600px;
    }
</style>
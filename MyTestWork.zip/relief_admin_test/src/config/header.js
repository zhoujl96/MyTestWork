import Vue from 'vue'
import axios from 'axios'
import GLOBAL_CONFIG from './config'
import router from '../router'

// 设置默认的配置项
const CONFIG = GLOBAL_CONFIG['GLOBAL_CONFIG'];

axios.defaults.timeout = 10000;

//添加请求拦截器
axios.interceptors.request.use(function(config){
	let TOKEN = localStorage.token;
	// 设置token
	if (TOKEN) {
       config.headers['X-EDUAPI-Authorization'] = TOKEN;
       config.headers['Login-Source'] = CONFIG['login_source'];
	}
	// 返回配置项
    return config;

},function(error){
    //请求错误时做些事
    return Promise.reject(error);
});

//添加响应拦截器
axios.interceptors.response.use(function(response){
    if (response.status === 200) {
        return response.data;
    }else{
        
    }
},function(error){
    return Promise.reject(error);
})

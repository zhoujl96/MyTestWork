
export default {
	GLOBAL_CONFIG :{
		// 本地测试配置
		'API_HOST': 'http://www.relief.com:8080/api',
		
		'login_source':'web'
	}
}
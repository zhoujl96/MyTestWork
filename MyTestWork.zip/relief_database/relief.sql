/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : relief

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2021-09-03 11:38:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_relief_category
-- ----------------------------
DROP TABLE IF EXISTS `t_relief_category`;
CREATE TABLE `t_relief_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '物资类别id',
  `name` varchar(255) DEFAULT NULL COMMENT '物资类别中文名称',
  `up_id` int(10) unsigned DEFAULT NULL COMMENT '所属物资类别，为0时无所属',
  `active` tinyint(4) unsigned DEFAULT '1' COMMENT '该物资类别是否有效,1为有效，0为无效',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='物质类别表';

-- ----------------------------
-- Records of t_relief_category
-- ----------------------------
INSERT INTO `t_relief_category` VALUES ('1', '全部类别', '0', '1');
INSERT INTO `t_relief_category` VALUES ('2', '救灾物资', '1', '1');
INSERT INTO `t_relief_category` VALUES ('3', '森林防火设备', '1', '1');
INSERT INTO `t_relief_category` VALUES ('4', '居住类', '2', '1');
INSERT INTO `t_relief_category` VALUES ('5', '床上用品类', '2', '1');
INSERT INTO `t_relief_category` VALUES ('6', '衣着类', '2', '1');
INSERT INTO `t_relief_category` VALUES ('7', '救灾设备类', '2', '1');
INSERT INTO `t_relief_category` VALUES ('8', '基本生活类', '2', '1');
INSERT INTO `t_relief_category` VALUES ('9', '其它', '2', '1');
INSERT INTO `t_relief_category` VALUES ('10', '居住子类0', '4', '1');
INSERT INTO `t_relief_category` VALUES ('11', '居住子类2', '4', '1');
INSERT INTO `t_relief_category` VALUES ('12', '居住子类3', '4', '1');
INSERT INTO `t_relief_category` VALUES ('13', '消防栓', '3', '1');
INSERT INTO `t_relief_category` VALUES ('14', '消防栓2', '13', '1');
INSERT INTO `t_relief_category` VALUES ('15', '居住子类4', '4', '1');
INSERT INTO `t_relief_category` VALUES ('16', '救灾', '1', '1');
INSERT INTO `t_relief_category` VALUES ('17', '测试', '1', '1');
INSERT INTO `t_relief_category` VALUES ('18', '测试2', '1', '1');

-- ----------------------------
-- Table structure for t_relief_store_type
-- ----------------------------
DROP TABLE IF EXISTS `t_relief_store_type`;
CREATE TABLE `t_relief_store_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '储备类型id',
  `name` varchar(255) DEFAULT NULL COMMENT '储备类型名称',
  `active` tinyint(4) unsigned DEFAULT '1' COMMENT '储备类型是否有效',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='储备类型表';

-- ----------------------------
-- Records of t_relief_store_type
-- ----------------------------
INSERT INTO `t_relief_store_type` VALUES ('1', '自储存', '1');
INSERT INTO `t_relief_store_type` VALUES ('2', '储存类型1', '1');
INSERT INTO `t_relief_store_type` VALUES ('3', '储存类型2', '1');
INSERT INTO `t_relief_store_type` VALUES ('4', '储存类型3', '1');

-- ----------------------------
-- Table structure for t_relief_supplies
-- ----------------------------
DROP TABLE IF EXISTS `t_relief_supplies`;
CREATE TABLE `t_relief_supplies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '物资条目id',
  `name` varchar(255) DEFAULT NULL COMMENT '物资品名',
  `category_id` int(10) unsigned DEFAULT NULL COMMENT '物资类别id',
  `category` varchar(255) DEFAULT NULL COMMENT '物资类别名称',
  `unit` varchar(255) DEFAULT NULL COMMENT '计量单位',
  `size` varchar(255) DEFAULT NULL COMMENT '规格/型号',
  `active` tinyint(4) unsigned DEFAULT '1' COMMENT '是否有效',
  `storeType_id` int(10) unsigned DEFAULT NULL COMMENT '储备类型id',
  `storeType` varchar(255) DEFAULT NULL COMMENT '储备类型名称',
  `order` int(10) unsigned DEFAULT NULL COMMENT '排序',
  `weight` varchar(255) DEFAULT NULL COMMENT '物资重量',
  `volume` varchar(255) DEFAULT NULL COMMENT '物资体积',
  `usage` varchar(255) DEFAULT NULL COMMENT '物资用途',
  `exit` tinyint(4) unsigned DEFAULT '1' COMMENT '是否被删除，0为删除，1为未删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='物资条目详情表';

-- ----------------------------
-- Records of t_relief_supplies
-- ----------------------------
INSERT INTO `t_relief_supplies` VALUES ('1', '救灾帐篷', '2', '救灾物资', 'm²', '15m²', '1', '1', '自储存', '10', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('2', '救灾帐篷', '2', '救灾物资', 'm²', '20m²', '1', '1', '自储存', '11', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('3', '移动桌椅', '2', '救灾物资', 'm³', '0.85m*0.67m*0.66m', '1', '1', '自储存', '12', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('4', '防潮垫', '2', '救灾物资', 'm²', '1.5m*2.0m', '1', '1', '自储存', '13', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('5', '折叠床', '2', '救灾物资', 'm³', '1.85m*0.7m*0.35m', '1', '1', '自储存', '14', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('6', '彩条布', '2', '救灾物资', 'g/m', '150g/m*2', '1', '1', '自储存', '15', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('7', '棉被', '2', '救灾物资', 'm²', '1.2m*2.2m', '1', '1', '自储存', '20', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('8', '毛巾被', '2', '救灾物资', 'm²', '1.5m*2.0m', '1', '1', '自储存', '21', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('9', '清凉被', '2', '救灾物资', 'm²', '1.5m*2.2m', '1', '1', '自储存', '22', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('10', '毛毯', '2', '救灾物资', 'm²', '1.5m*2.2m', '1', '1', '自储存', '23', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('11', '救灾帐篷', '2', '救灾物资', 'm²', '12m²', '1', '1', '自储存', '10', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('12', '救灾帐篷', '2', '救灾物资', 'm²', '20m²', '1', '1', '自储存', '11', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('13', '移动桌椅', '2', '救灾物资', 'm³', '0.85m*0.67m*0.66m', '1', '1', '自储存', '12', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('14', '防潮垫', '2', '救灾物资', 'm²', '1.5m*2.0m', '1', '1', '自储存', '13', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('15', '折叠床', '2', '救灾物资', 'm³', '1.85m*0.7m*0.35m', '1', '1', '自储存', '14', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('16', '彩条布', '2', '救灾物资', 'g/m', '150g/m*2', '1', '1', '自储存', '15', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('17', '棉被', '2', '救灾物资', 'm²', '1.2m*2.2m', '1', '1', '自储存', '20', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('18', '毛巾被', '2', '救灾物资', 'm²', '1.5m*2.0m', '1', '1', '自储存', '21', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('19', '清凉被', '2', '救灾物资', 'm²', '1.5m*2.2m', '1', '1', '自储存', '22', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('20', '毛毯', '2', '救灾物资', 'm²', '1.5m*2.2m', '1', '1', '自储存', '23', '100kg', '10m³', '遮风挡雨', '1', '2021-09-03 09:00:00');
INSERT INTO `t_relief_supplies` VALUES ('21', '帐篷', '10', '居住子类0', '顶', '12m²', '1', '2', '储存类型1', '30', '10kg', '11m³', '住所安置', '1', '2021-09-03 10:02:00');

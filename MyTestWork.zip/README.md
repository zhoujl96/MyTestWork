## 环境部署 ##

该项目前端页面基于Vue+elementUI开发，服务端接口则是运用了PHP的laravel框架，数据库使用的是mysql。所以针对以上内容，要运行好项目需要进行以下工具准备以及环境部署。

首先是需要有PHP集成环境，这里我使用的是PhPstudy,有其他类似的工具也可以。接着是数据库管理工具，我使用的是Navicat，其它的工具也行。这个项目全程是在谷歌浏览器上测试开发的，没有出现问题，也可以尝试在其他浏览器上运行，出现问题可以向我反馈。还有就是命令行工具，我用的是cmder,也可以用系统自带的或者VS code上的。然后是laravel框架需要安装composer,Vue框架需要npm,不多赘述。

环境部署好后，就可以运行项目了。目录有3个文件夹，relief\_admin\_test是这次要测试的项目，relief\_api\_test是服务端接口，relief\_database
里是mysql数据库文件。

## 项目运行 ##

首先打开PHP集成开发工具，运行Apache和MySQL套件，接着创建一个本地网站，网站域名为www.relief.com,端口为8080,也可以是别的，但是要修改relief\_admin\_test文件夹 src/config/config.js文件里的配置，保持一致。接着将网站入口设置在relief\_api\_test的public目录那里。这样服务端就设置好了。

接着是数据库部署，该项目数据库名字是relief,用户名用的是root,密码是root123。同样也可以用别的，不过需要修改relief\_api\_test服务端文件夹中.env文件以及config/database.php文件对应位置，要保持一致。接着是将relief_database里的relief.sql文件右键点击对应数据库运行导入即可。

最后就是用命令行打开relief\_admin\_test目录，先运行`npm install`, 完成后再运行`npm run dev`，等编译完成根据其提示的网址打开浏览器访问就可以了。

